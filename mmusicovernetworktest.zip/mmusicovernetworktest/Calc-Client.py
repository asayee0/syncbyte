import socket 

client_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

host = socket.gethostbyname('localhost')
port = 5555
server_addr = (host, port)

response = None 
terminator =bytes('', 'UTF-8')
while response != terminator:
    message = input('Please enter code:')
    message = bytes(message, 'UTF-8')
    client_sock.sendto(message, server_addr)
    response, _ = client_sock.recvfrom(1024)
    if response!=terminator:
        response=str(response)
        print("answer from server",response[2:(len(response)-1)])
        response=bytes(response,'UTF-8')

client_sock.close()

