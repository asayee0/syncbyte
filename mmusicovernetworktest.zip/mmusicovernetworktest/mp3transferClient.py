from __future__ import print_function
import socket               # Import socket module

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)         # Create a socket object
host = socket.gethostbyname('localhost') # Get local machine name (host to connect to)
port = 5555               # Reserve a port for your service.


server_addr = (host, port)
s.connect(server_addr)

f = open('testsuccess.mp3','wb') # Open in binary

while True:
    musfile=s.recv(4096) 
    #musfile=musfile.decode()
    if not musfile:
        break
    f.write(musfile)
print('writing to file complete')
f.close()
    

    
    
s.close()               # Close the socket when done
