from __future__ import print_function
import socket 

# create a TCP socket for the server
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# get the address of localhost
host = socket.gethostbyname('localhost')
port = 5555

# set options to circumvent proper socket release
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

# create pair for host address (this machine)
host_addr = (host, port)
s.bind(host_addr) # bind socket to aforementioned address


# make socket at server listen for incoming inconnections
s.listen(10)
print('Starting to listen for requests')

f = open('testfile3.mp3','rb') #open in binary
#while True:
c, addr = s.accept() # accept connection from client
print('Got connection from ', addr)
tosend=f.read()
c.sendall(tosend)
print('sending complete')

c.close() # close connection after processing

