#my program executed well for what I assume to be the parametres/ scope of
#the program. Therefor I believe i have done 100% of the requirements
import socket
import sys


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = socket.gethostbyname('localhost')
port = 5555
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
host_addr = (host, port)
s.bind(host_addr) # bind socket to aforementioned address
option =True
print('Ready....')
f = open('testfile.mp3','wb') # Open in binary
while option:

          

